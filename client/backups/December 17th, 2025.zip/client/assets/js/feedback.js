// FEEDBACK PAGE LOGIC (FULLY REVISED)
document.addEventListener("DOMContentLoaded", () => {
    // Elements
    const problemType = document.getElementById("problemType");
    const sampleSection = document.getElementById("sampleTestSection");
    const ratingSection = document.getElementById("ratingSection");
    const form = document.getElementById("feedbackForm");

    const stars = document.querySelectorAll(".rating-stars .star");
    const output = document.getElementById("ratingOutput");

    const fbUniversity = document.getElementById("fbUniversity");
    const fbYear = document.getElementById("fbYear");
    const fbSemester = document.getElementById("fbSemester");
    const fbType = document.getElementById("fbType");

    const searchInput = document.getElementById("searchInput");
    const searchSuggestions = document.getElementById("searchSuggestions");

    // State
    let selectedRating = 0;
    let selectedTestId = null;
    let selectedKeywordId = null;

    // Initial state
    sampleSection.classList.add("d-none");
    ratingSection.classList.add("d-none");

    // -----------------------------
    // UTILITY FUNCTIONS
    // -----------------------------
    function clearStars() {
        stars.forEach(s => s.className = "star");
        selectedRating = 0;
        if (output) output.textContent = "Rating is: 0 / 5";
    }

    function populateSelect(selectEl, items) {
        selectEl.innerHTML = '';
        const placeholder = selectEl.dataset.placeholder || "Select...";
        selectEl.innerHTML = `<option value="" disabled selected hidden>${placeholder}</option>`;
        items.forEach(item => {
            const opt = document.createElement("option");
            opt.value = item.id;
            opt.textContent = item.name;
            selectEl.appendChild(opt);
        });
        selectEl.disabled = false;
    }

    async function loadFiltersForSubject(subjectId) {
        if (!subjectId) return;

        const payload = {
            subject_id: subjectId,
            university: fbUniversity.value || null,
            year: fbYear.value || null,
            semester: fbSemester.value || null,
            type: fbType.value || null
        };

        try {
            const res = await fetch("/api/tests/filters", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload)
            });

            if (!res.ok) throw new Error("Failed to fetch filters");

            const data = await res.json();

            populateSelect(fbUniversity, data.universities);
            populateSelect(fbYear, data.years);
            populateSelect(fbSemester, data.semesters);
            populateSelect(fbType, data.types);

        } catch (err) {
            console.error("Error loading filters for subject:", err);
        }
    }


    async function resolveTestId() {
        if (!selectedKeywordId || !fbUniversity.value || !fbYear.value || !fbSemester.value || !fbType.value) {
            selectedTestId = null;
            return;
        }
        try {
            const res = await fetch("/api/tests/resolve", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    keyword_id: selectedKeywordId,
                    university: fbUniversity.value,
                    year: fbYear.value,
                    semester: fbSemester.value,
                    type: fbType.value
                })
            });
            if (!res.ok) {
                console.error("Resolve test failed");
                selectedTestId = null;
                return;
            }
            const data = await res.json();
            selectedTestId = data.test_id || null;
        } catch (err) {
            console.error("Failed to resolve test ID:", err);
        }
    }

    // -----------------------------
    // EVENT HANDLERS
    // -----------------------------
    // Problem type toggle
    problemType.addEventListener("change", () => {
        if (problemType.value === "sample_test") {
            sampleSection.classList.remove("d-none");
            ratingSection.classList.remove("d-none");
        } else {
            sampleSection.classList.add("d-none");
            ratingSection.classList.add("d-none");
            clearStars();
            selectedTestId = null;
        }
    });

    // Star rating
    stars.forEach((star, idx) => {
        star.addEventListener("click", () => {
            selectedRating = Number(star.dataset.value);
            stars.forEach((s, i) => {
                s.className = "star"; // reset
                if (i < selectedRating) s.classList.add("selected");
            });
            output.textContent = `Rating is: ${selectedRating} / 5`;
        });
    });

    // Autocomplete search
    searchInput.addEventListener("input", async () => {
        const q = searchInput.value.trim();
        searchSuggestions.innerHTML = '';
        selectedKeywordId = null;

        if (!q) return;

        try {
            const res = await fetch(`/api/subjects/autocomplete?q=${encodeURIComponent(q)}`);
            if (!res.ok) return;

            const subjects = await res.json();
            subjects.forEach(subj => {
                const item = document.createElement("div");
                item.className = "list-group-item list-group-item-action";
                item.textContent = subj.title;
                item.dataset.id = subj.id;

                item.addEventListener("click", async () => {
                    searchInput.value = subj.title;
                    selectedKeywordId = subj.id;
                    searchSuggestions.innerHTML = '';
                    await loadFiltersForSubject(selectedKeywordId);
                    resolveTestId();
                });

                searchSuggestions.appendChild(item);
            });
        } catch (err) {
            console.error("Autocomplete failed:", err);
        }
    });

    // Filters change
    [fbUniversity, fbYear, fbSemester, fbType].forEach(el => {
        el.addEventListener("change", async () => {
            await loadFiltersForSubject(selectedKeywordId);
            resolveTestId();
        });
    });

    // -----------------------------
    // FORM SUBMISSION
    // -----------------------------
    form.addEventListener("submit", async (e) => {
        e.preventDefault();

        const fullname = document.getElementById("fullname").value.trim();
        const email = document.getElementById("email").value.trim();
        const dob = document.getElementById("dob").value.trim();
        const description = document.getElementById("description").value.trim();

        if (!fullname || !email || !description) {
            alert("Please fill in all required fields");
            return;
        }

        if (problemType.value === "sample_test") {
            if (!selectedTestId) {
                alert("Please select a valid sample test");
                return;
            }
            if (selectedRating < 1) {
                alert("Please provide a rating for the sample test");
                return;
            }
        }

        const payload = {
            user_fullname: fullname,
            email,
            dob,
            problem_type: problemType.value,
            test_id: selectedTestId,
            rating: selectedRating,
            description
        };

        try {
            const res = await fetch("/api/feedback", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload)
            });

            if (!res.ok) {
                alert("Failed to submit feedback");
                return;
            }

            alert("Feedback submitted successfully!");
            form.reset();
            clearStars();
            selectedTestId = null;
            selectedKeywordId = null;
            sampleSection.classList.add("d-none");
            ratingSection.classList.add("d-none");
            searchSuggestions.innerHTML = '';
        } catch (err) {
            console.error("Feedback submission failed:", err);
            alert("Error submitting feedback");
        }
    });

    // Reset button
    form.addEventListener("reset", () => {
        clearStars();
        selectedTestId = null;
        selectedKeywordId = null;
        sampleSection.classList.add("d-none");
        ratingSection.classList.add("d-none");
        searchSuggestions.innerHTML = '';
    });
});
