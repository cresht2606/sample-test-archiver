// Key endpoints: search, filters, get by id
const express = require('express');
const router = express.Router();
const pool = require('../utils/db');

// Filters: GET /api/tests?query=&university=&year=&semester=&type=
router.get('/', async (req, res) => {
    const { query = '', university, year, semester, type } = req.query;
    const params = [];
    let where = 'WHERE 1 = 1';

    // Keyword sort
    if (query) {
        where += ' AND title LIKE ?';
        params.push(`%${query}%`);
    }

    // University filter
    if (university) {
        where += ' AND university = ?';
        params.push(university);
    }

    // Year filter
    if (year) {
        where += ' AND year = ?';
        params.push(year);
    }

    // Semester filter
    if (semester) {
        where += ' AND semester = ?';
        params.push(semester);
    }

    // Type (Mid-term, Final-term)
    if (type) {
        where += ' AND type = ?';
        params.push(type);
    }

    try {
        const [rows] = await pool.query(`SELECT * FROM tests ${where} ORDER BY created_at DESC LIMIT 500`, params);
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({
            error: 'db_error'
        });
    }
});

router.get("/filters", async (req, res) => {
    try {
        const [universities] = await pool.query(`
            SELECT DISTINCT university AS name, university AS id
            FROM tests
            ORDER BY university
        `);

        const [years] = await pool.query(`
            SELECT DISTINCT year AS name, year AS id
            FROM tests
            ORDER BY year DESC
        `);

        const [semesters] = await pool.query(`
            SELECT DISTINCT semester AS name, semester AS id
            FROM tests
            ORDER BY semester
        `);

        const [types] = await pool.query(`
            SELECT DISTINCT type AS name, type AS id
            FROM tests
            ORDER BY type
        `);

        res.json({
            universities,
            years,
            semesters,
            types
        });

    } catch (err) {
        console.error("Failed to load filters:", err);
        res.status(500).json({ error: "Failed to load filters" });
    }
});

// POST /api/tests/resolve (Resolve test ID from filters)
router.post("/resolve", async (req, res) => {
    const { university, year, semester, type } = req.body;

    if (!university || !year || !semester || !type) {
        return res.json({ test_id: null });
    }

    try {
        const [rows] = await pool.query(
            `
            SELECT id
            FROM tests
            WHERE university = ?
              AND year = ?
              AND semester = ?
              AND type = ?
            LIMIT 1
            `,
            [university, year, semester, type]
        );

        if (!rows.length) {
            return res.json({ test_id: null });
        }

        res.json({ test_id: rows[0].id });

    } catch (err) {
        console.error("Failed to resolve test ID:", err);
        res.status(500).json({ error: "Failed to resolve test ID" });
    }
});



// GET /api/tests/:id
router.get('/:id', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM tests where id = ? LIMIT 1', [req.params.id]); // Unique ID for single test
        if (!rows.length) {
            return res.status(404).json({
                error: 'not_found'
            });
        };
        res.json(rows[0]);

    } catch (err) {
        console.error(err);
        res.status(500).json({
            error: 'db_error'
        });
    }
});

// Get rating per test
router.get("/:id/rating", async (req, res) => {
    const testId = req.params.id;
    try {
        const result = await db.query(
            `SELECT avg_rating, total_reviews FROM test_ratings WHERE test_id = $1`,
            [testId]
        );

        if (result.rows.length === 0) return res.json({ avg_rating: 0, total_reviews: 0 });

        res.json(result.rows[0]);
    } catch (err) {
        console.error("Rating fetch failed:", err);
        res.status(500).json({ error: "Internal server error" });
    }
});


//View counter by session
router.post('/view/:id', async (req, res) => {
    const testId = req.params.id;
    try {
        const [result] = await pool.query(
            'UPDATE tests SET views = views + 1 WHERE id = ?', [testId]
        );
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'not_found' });
        }
        res.json({ success: true });
    } catch (err) {
        console.error('View update failed:', err);
        res.status(500).json({ error: 'db_error' });
    }
});

module.exports = router;
