// FEEDBACK PAGE LOGIC (FULLY REVISED)
document.addEventListener("DOMContentLoaded", () => {
    // Elements
    const problemType = document.getElementById("problemType");
    const sampleSection = document.getElementById("sampleTestSection");
    const ratingSection = document.getElementById("ratingSection");
    const form = document.getElementById("feedbackForm");

    const stars = document.querySelectorAll(".rating-stars .star");
    const output = document.getElementById("ratingOutput");

    const fbUniversity = document.getElementById("fbUniversity");
    const fbYear = document.getElementById("fbYear");
    const fbSemester = document.getElementById("fbSemester");
    const fbType = document.getElementById("fbType");

    const searchInput = document.getElementById("searchInput");
    const searchSuggestions = document.getElementById("searchSuggestions");

    // State
    let selectedRating = 0;
    let selectedTestId = null;
    let selectedKeywordId = null;

    // Initial state
    sampleSection.classList.add("d-none");
    ratingSection.classList.add("d-none");

    // Debug helper
    function logState() {
        console.log("=== Current State ===");
        console.log("selectedKeywordId:", selectedKeywordId);
        console.log("selectedTestId:", selectedTestId);
        console.log("selectedRating:", selectedRating);
        console.log("University:", fbUniversity.value);
        console.log("Year:", fbYear.value);
        console.log("Semester:", fbSemester.value);
        console.log("Type:", fbType.value);
        console.log("===================");
    }

    // -----------------------------
    // UTILITY FUNCTIONS
    // -----------------------------
    function clearStars() {
        stars.forEach(s => s.classList.remove("selected"));
        selectedRating = 0;
        if (output) output.textContent = "Rating is: 0 / 5";
    }

    function populateSelect(selectEl, items) {
        if (!selectEl) {
            console.error("Select element is null");
            return;
        }
        
        const placeholderText = selectEl.options[0].text;
        selectEl.innerHTML = '';
        selectEl.innerHTML = `<option value="" disabled selected hidden>${placeholderText}</option>`;
        
        if (!items || items.length === 0) {
            selectEl.disabled = true;
            console.log(`${selectEl.id}: No items to populate`);
            return;
        }
        
        items.forEach(item => {
            const option = document.createElement('option');
            option.value = item.name || item.id || item;
            option.textContent = item.name || item.id || item;
            selectEl.appendChild(option);
        });
        
        selectEl.disabled = false;
        console.log(`${selectEl.id}: Populated with ${items.length} items`);
    }

    async function loadFiltersForSubject(subjectId) {
        if (!subjectId) return;

        console.log("Loading filters for subject:", subjectId, "with optional filters:", {
            university: fbUniversity.value || null,
            year: fbYear.value || null,
            semester: fbSemester.value || null
        });

        try {
            // Build query with optional filter parameters
            const params = new URLSearchParams();
            params.append('subject_id', subjectId);
            if (fbUniversity.value) params.append('university', fbUniversity.value);
            if (fbYear.value) params.append('year', fbYear.value);
            if (fbSemester.value) params.append('semester', fbSemester.value);

            const res = await fetch(`/api/tests/filters?${params.toString()}`);

            if (!res.ok) {
                console.error("Failed to fetch filters:", res.status);
                return;
            }

            const data = await res.json();
            console.log("Received filters:", data);

            // Populate based on what's selected
            if (fbUniversity.value && fbYear.value && fbSemester.value) {
                // All selected - just populate types
                populateSelect(fbType, data.types);
            } else if (fbUniversity.value && fbYear.value) {
                // University and year selected - populate semesters and types
                populateSelect(fbSemester, data.semesters);
                populateSelect(fbType, data.types);
            } else if (fbUniversity.value) {
                // Only university selected - populate year, semesters, and types
                populateSelect(fbYear, data.years);
                fbSemester.innerHTML = '<option value="" disabled selected hidden>Semester</option>';
                fbType.innerHTML = '<option value="" disabled selected hidden>Type</option>';
                fbSemester.disabled = true;
                fbType.disabled = true;
            } else {
                // Initial load - populate all
                populateSelect(fbUniversity, data.universities);
                populateSelect(fbYear, data.years);
                fbSemester.innerHTML = '<option value="" disabled selected hidden>Semester</option>';
                fbType.innerHTML = '<option value="" disabled selected hidden>Type</option>';
                fbSemester.disabled = true;
                fbType.disabled = true;
            }

        } catch (err) {
            console.error("Error loading filters for subject:", err);
        }
    }

    async function resolveTestId() {
        console.log("=== Attempting to resolve test ID ===");
        
        if (!selectedKeywordId) {
            console.log("No subject selected");
            selectedTestId = null;
            return;
        }
        
        if (!fbUniversity.value || !fbYear.value || !fbSemester.value || !fbType.value) {
            console.log("Not all filters selected yet");
            selectedTestId = null;
            return;
        }
        
        const params = {
            subject_id: selectedKeywordId,
            university: fbUniversity.value,
            year: String(fbYear.value),  // Ensure year is a string
            semester: fbSemester.value,
            type: fbType.value
        };
        
        console.log("Resolving test with params:", params);

        try {
            const res = await fetch("/api/tests/resolve", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(params)
            });
            
            if (!res.ok) {
                console.error("Resolve test failed:", res.status);
                selectedTestId = null;
                return;
            }
            
            const data = await res.json();
            selectedTestId = data.test_id || null;
            console.log("✅ Resolved test ID:", selectedTestId);
            
            if (!selectedTestId) {
                console.warn("⚠️ No matching test found for these filters");
                // Check browser console for details
            }
            
        } catch (err) {
            console.error("Failed to resolve test ID:", err);
            selectedTestId = null;
        }
    }

    // -----------------------------
    // EVENT HANDLERS
    // -----------------------------
    
    // Problem type toggle
    problemType.addEventListener("change", () => {
        const isSampleTest = problemType.value === "sample_test";
        
        if (isSampleTest) {
            sampleSection.classList.remove("d-none");
            ratingSection.classList.remove("d-none");
        } else {
            sampleSection.classList.add("d-none");
            ratingSection.classList.add("d-none");
            clearStars();
            selectedTestId = null;
            selectedKeywordId = null;
            searchInput.value = "";
            searchSuggestions.innerHTML = "";
        }
    });

    // Star rating
    stars.forEach((star, idx) => {
        star.addEventListener("click", () => {
            selectedRating = idx + 1;
            stars.forEach((s, i) => {
                if (i < selectedRating) {
                    s.classList.add("selected");
                } else {
                    s.classList.remove("selected");
                }
            });
            if (output) output.textContent = `Rating is: ${selectedRating} / 5`;
            console.log("Rating selected:", selectedRating);
        });
    });

    // Autocomplete search
    let acTimer = null;
    searchInput.addEventListener("input", async () => {
        clearTimeout(acTimer);
        const q = searchInput.value.trim();

        if (!q) {
            searchSuggestions.innerHTML = "";
            return;
        }

        acTimer = setTimeout(async () => {
            try {
                const res = await fetch(`/api/subjects/autocomplete?q=${encodeURIComponent(q)}`);
                const subjects = await res.json();

                searchSuggestions.innerHTML = "";

                if (!subjects.length) {
                    return;
                }

                subjects.forEach(sub => {
                    const li = document.createElement("li");
                    li.className = "list-group-item list-group-item-action";
                    li.style.cursor = "pointer";
                    li.textContent = sub.title;
                    li.addEventListener("click", () => {
                        searchInput.value = sub.title;
                        selectedKeywordId = sub.id;
                        searchSuggestions.innerHTML = "";
                        
                        console.log("✅ Selected subject:", sub.id, sub.title);
                        loadFiltersForSubject(sub.id);
                    });
                    searchSuggestions.appendChild(li);
                });

            } catch (err) {
                console.error("Autocomplete error:", err);
            }
        }, 300);
    });

    // Close autocomplete when clicking outside
    document.addEventListener("click", (e) => {
        if (!searchInput.contains(e.target) && !searchSuggestions.contains(e.target)) {
            searchSuggestions.innerHTML = "";
        }
    });

    // Filters change - cascade logic (only reload when necessary)
    fbUniversity.addEventListener("change", async () => {
        console.log("University changed to:", fbUniversity.value);
        // Reset year, semester, type when university changes
        fbYear.innerHTML = '<option value="" disabled selected hidden>Year</option>';
        fbSemester.innerHTML = '<option value="" disabled selected hidden>Semester</option>';
        fbType.innerHTML = '<option value="" disabled selected hidden>Type</option>';
        fbYear.disabled = true;
        fbSemester.disabled = true;
        fbType.disabled = true;
        selectedTestId = null;
        
        // Reload filters for this university
        if (selectedKeywordId && fbUniversity.value) {
            await loadFiltersForSubject(selectedKeywordId);
        }
    });

    fbYear.addEventListener("change", async () => {
        console.log("Year changed to:", fbYear.value);
        // Reset semester and type when year changes
        fbSemester.innerHTML = '<option value="" disabled selected hidden>Semester</option>';
        fbType.innerHTML = '<option value="" disabled selected hidden>Type</option>';
        fbSemester.disabled = true;
        fbType.disabled = true;
        selectedTestId = null;
        
        // Reload filters for this year
        if (selectedKeywordId && fbUniversity.value && fbYear.value) {
            await loadFiltersForSubject(selectedKeywordId);
        }
    });

    fbSemester.addEventListener("change", async () => {
        console.log("Semester changed to:", fbSemester.value);
        // Reset type when semester changes
        fbType.innerHTML = '<option value="" disabled selected hidden>Type</option>';
        fbType.disabled = true;
        selectedTestId = null;
        
        // Load types for this semester
        if (selectedKeywordId && fbUniversity.value && fbYear.value && fbSemester.value) {
            try {
                const params = new URLSearchParams();
                params.append('subject_id', selectedKeywordId);
                params.append('university', fbUniversity.value);
                params.append('year', fbYear.value);
                params.append('semester', fbSemester.value);

                const res = await fetch(`/api/tests/filters?${params.toString()}`);
                if (!res.ok) return;

                const data = await res.json();
                console.log("Received types for semester:", data.types);
                populateSelect(fbType, data.types);
            } catch (err) {
                console.error("Error loading types:", err);
            }
        }
    });

    fbType.addEventListener("change", async () => {
        console.log("Type changed to:", fbType.value);
        await resolveTestId();
        logState();
    });

    // -----------------------------
    // FORM SUBMISSION
    // -----------------------------
    form.addEventListener("submit", async (e) => {
        e.preventDefault();

        console.log("=== Form Submission ===");
        logState();

        const fullname = document.getElementById("fullname").value.trim();
        const email = document.getElementById("email").value.trim();
        const dob = document.getElementById("dob").value;
        const description = document.getElementById("description").value.trim();
        const probType = problemType.value;

        if (!fullname || !email || !probType || !description) {
            alert("Please fill in all required fields.");
            return;
        }

        if (probType === "sample_test") {
            if (!selectedTestId) {
                alert("Please select a valid sample test using the filters.");
                console.error("Submit failed: No test_id resolved");
                return;
            }
            if (!selectedRating) {
                alert("Please provide a rating for the sample test.");
                return;
            }
        }

        const payload = {
            user_fullname: fullname,
            email,
            dob: dob || null,
            problem_type: probType,
            test_id: selectedTestId,
            rating: selectedRating || null,
            description
        };

        console.log("Submitting feedback:", payload);

        try {
            const res = await fetch("/api/feedback", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload)
            });

            if (!res.ok) {
                const errData = await res.json();
                alert(`Error: ${errData.error || "Failed to submit feedback"}`);
                return;
            }

            alert("✅ Feedback submitted successfully! Thank you.");
            form.reset();
            clearStars();
            sampleSection.classList.add("d-none");
            ratingSection.classList.add("d-none");
            searchSuggestions.innerHTML = "";
            selectedTestId = null;
            selectedKeywordId = null;

        } catch (err) {
            console.error("Submission error:", err);
            alert("An error occurred while submitting feedback. Please try again.");
        }
    });

    // Reset button
    form.addEventListener("reset", () => {
        clearStars();
        sampleSection.classList.add("d-none");
        ratingSection.classList.add("d-none");
        searchSuggestions.innerHTML = "";
        selectedTestId = null;
        selectedKeywordId = null;
    });
});